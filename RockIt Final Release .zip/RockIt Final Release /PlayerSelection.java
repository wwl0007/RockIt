import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Class to conduct behavior as far as player selection goes.
 * 
 * @author War Eagle Studios 
 * @version 11/19/2020
 */
public class PlayerSelection extends Actor
{
    /**
     * Act method for the PlayerSelection class.
     */
    public void act() 
    {
        // No code. This method was scrapped in development.
    }    
}
